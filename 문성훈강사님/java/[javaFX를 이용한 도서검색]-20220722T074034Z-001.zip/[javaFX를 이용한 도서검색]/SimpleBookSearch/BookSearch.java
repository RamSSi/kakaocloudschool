package SimpleBookSearch;

import java.util.List;

import SimpleBookSearch.service.BookService;
import SimpleBookSearch.vo.BookEntity;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class BookSearch extends Application {

	TextArea textarea;
	TextField input;
	Button selectBtn,deleteBtn;
	
	BookService service = new BookService();
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
	
		BorderPane root = new BorderPane();
		root.setPrefSize(700, 500);
		
		textarea = new TextArea();
		textarea.setEditable(false);
		root.setCenter(textarea);
		
		BorderPane bottom = new BorderPane();
		bottom.setPrefHeight(40);
		bottom.setPrefWidth(Double.MAX_VALUE);
		
		selectBtn = new Button("Keyword검색");
		selectBtn.setPrefSize(100, 60);
		selectBtn.setOnAction(e -> {
			textarea.clear();
			List<BookEntity> result = service.searchByKeyword(input.getText());
			result.stream()
			      .forEach(t -> {
			    	  Platform.runLater(() -> {
			    		  textarea.appendText(t.getBtitle() + " : " + 
			    				  			  t.getBauthor() + " : " + 
			    				              t.getBisbn() + "\n");
			    	  });
			      });
		});
		input = new TextField();
		input.setPrefSize(40, 60);
		deleteBtn = new Button("ISBN으로 삭제");		
		deleteBtn.setPrefSize(100, 60);
		deleteBtn.setOnAction(e-> {
			boolean result = service.deleteByISBN(input.getText());
			Platform.runLater(()->{
				if(result) {
					textarea.appendText("[삭제성공] \n");
				} else {
					textarea.appendText("[삭제실패] \n");
				}
			});
		});
		
		bottom.setLeft(selectBtn);
		bottom.setCenter(input);
		bottom.setRight(deleteBtn);
		
		root.setBottom(bottom);
		
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.setTitle("도서검색 및 삭제");
		primaryStage.show();
		
	}

	public static void main(String[] args) {
		launch();
	}

}