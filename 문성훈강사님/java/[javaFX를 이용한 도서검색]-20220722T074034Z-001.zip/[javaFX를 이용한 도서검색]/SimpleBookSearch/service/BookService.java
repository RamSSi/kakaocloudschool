package SimpleBookSearch.service;

import java.util.List;

import SimpleBookSearch.dao.BookDAO;
import SimpleBookSearch.dao.ConnectionMaker;
import SimpleBookSearch.dao.ConnectionMakerImpl;
import SimpleBookSearch.vo.BookEntity;

public class BookService {

	private ConnectionMaker connectionMaker;
	
	public BookService() {
		this.connectionMaker = new ConnectionMakerImpl();
	}
	
	public List<BookEntity> searchByKeyword(String keyword) {
		// 로직
		// DB처리
		BookDAO dao = new BookDAO(connectionMaker);
		return dao.select(keyword);
	}

	public boolean deleteByISBN(String isbn) {
		// 로직
		// DB처리
		BookDAO dao = new BookDAO(connectionMaker);
		return dao.delete(isbn);
	}
}
