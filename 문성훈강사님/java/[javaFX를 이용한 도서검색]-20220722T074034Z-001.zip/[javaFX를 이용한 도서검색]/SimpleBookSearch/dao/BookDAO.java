package SimpleBookSearch.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import SimpleBookSearch.vo.BookEntity;

public class BookDAO {

	private ConnectionMaker connectionMaker; 
	
	public BookDAO(ConnectionMaker connectionMaker) {
		this.connectionMaker = connectionMaker;
	}
	
	public List<BookEntity> select(String keyword) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BookEntity> result = new ArrayList<BookEntity>();
		
		try {
			con = connectionMaker.getConnection();
			String sql = "select btitle,bauthor,bisbn from book where btitle like ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + keyword + "%");
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BookEntity book = new BookEntity();
				book.setBtitle(rs.getString("btitle"));
				book.setBauthor(rs.getString("bauthor"));
				book.setBisbn(rs.getString("bisbn"));
				result.add(book);
			}					
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return result;
	}

	public boolean delete(String isbn) {

		Connection con = null;
		PreparedStatement pstmt = null;
		boolean result = false;
		
		try {
			con = connectionMaker.getConnection();
			
			String sql = "delete from book where bisbn = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, isbn);
			
			int count = pstmt.executeUpdate();
			if ( count == 1 ) result = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return result;
	}

}
