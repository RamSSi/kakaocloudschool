package SimpleBookSearch.dao;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

public class ConnectionMakerImpl implements ConnectionMaker {

	private static BasicDataSource basicDS;

	static {
		try {
			basicDS = new BasicDataSource();
			Properties properties = new Properties();

			InputStream is = new FileInputStream("resources/db.properties");
			properties.load(is);

			basicDS.setDriverClassName(properties.getProperty("DRIVER_CLASS"));
			basicDS.setUrl(properties.getProperty("JDBC_URL"));
			basicDS.setUsername(properties.getProperty("DB_USER"));
			basicDS.setPassword(properties.getProperty("DB_PASSWORD"));

			basicDS.setInitialSize(10);
			basicDS.setMaxTotal(10);

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private static DataSource getDataSource() {
		return basicDS;
	}

	@Override
	public Connection getConnection() throws Exception {
		return getDataSource().getConnection();
	}
}
